In order to run the file, you need to have the excel spreadsheet movies.csv in the same directory. 
My section of the project pulls from an IMDB dataset and returns decade and genre. 
There was data from before the 1930s but I chose not to include it because there weren't many data points before then. 

CONTROLS:
Use the right and left arrows to cycle through the various decades included.