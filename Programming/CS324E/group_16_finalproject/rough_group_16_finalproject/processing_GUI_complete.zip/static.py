# Static GUI classes defined here
# i.e. GUI objects that aren't very interactive
# e.g. GUItext and GUIimage.

from guiheart import *

'''
This is the class for adding text to GUI objects.
Note that buttons don't need this, as they have text
built-in.'''
class GUItext(GUI):
    # Constructor
    def __init__(self, parent=None):
        GUI.__init__(self, parent)
        self.type = "GUItext"
        self.txt = "Text"
        self.txtsize = 12
        self.W = 0
        self.H = 0
        self.col = "#000000"
        self.align = LEFT

    # What text will be shown?
    # If given no args, returns current text.
    def text(self, txt=None):
        if txt == None:
            return self.txt
        self.txt = txt
        return self

   # Change text size.
   # Given no args, returns current size.
    def textSize(self, size=None):
        if size == None:
            return self.txtsize
        self.txtsize = size
        return self

    # Change text color.
    # Given no args, returns current text color.
    def textColor(self, col=None):
        if col == None:
            return self.col
        self.col = col
        return self

    # Set the alignment of the text. Valid inputs are:
    # LEFT, CENTER, RIGHT, or any other valid argument
    # for the Processing textAlign() function.
    def textAlign(self, align=None):
        if align == None:
            return self.align
        self.align = align
        return self

    # Set width of the text box
    def width(self, W=None):
        if W == None: return self.W
        self.W = W
        return self

    # Set height of the text box
    def height(self, H=None):
        if H == None: return self.H
        self.H = H
        return self

    # Set width and height of the text box
    def size(self, W=None, H=None):
        if W == None: return self.W, self.H
        if H == None: H = W
        self.W = W
        self.H = H
        return self

    # Display text on the screen
    def display(self):
        x,y = self.screenPosition()
        textSize(self.txtsize)
        fill(self.col)
        textAlign(self.align, TOP)
        if self.width() == 0 or self.height() == 0:
            text(self.txt, x, y)
        else:
            text(self.txt, x, y, self.W, self.H)
'''
This is the class for rendering PImages on a GUI object.'''
class GUIimage(GUI):
    # Constructor
    def __init__(self, parent=None):
        GUI.__init__(self, parent)
        self.type = "GUIimg"
        self.img = None

    def image(self, img=None):
        if img==None: return self.img
        self.img = img
        return self

    def display(self):
        if self.img == None: return
        x,y = self.screenPosition()
        image(self.img, x, y)
