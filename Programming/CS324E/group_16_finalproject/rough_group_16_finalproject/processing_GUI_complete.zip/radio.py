# Radio Button classes defined here.
from button import *

# RadioGroup class allows radio buttons to be grouped together.
# Children of RadioGroup are the associated radio buttons.
# Note that ONLY radio buttons can be children of a radio group!
class RadioGroup(GUI):
    # Constructor
    def __init__(self, parent=None):
        GUI.__init__(self, parent)
        self.activeChild = None

    # Activates the radio button radio in the radio group
    # Either radio button object can be given, or the index
    # of the radio button within the radio group's children list.
    # It's preferable to activate radio buttons from the .activate()
    # method within the radio BUTTON class, not the radio GROUP.
    # Mainly useful for activating based on index.
    def activate(self, radio):
        if radio not in self.children:
            print("ERROR! Tried to activate radio button that is not part of radio group!")
            1/0
        if type(radio) == type(0): radio = self.children[radio]
        radio.activate()
        self.activeChild = radio
        return self

    # Deactivates all the radio buttons in this radio group.
    def clear(self):
        for child in self.children: child.clear()

# RadioButton class allows for the creation of radio buttons
# in GUI's. RadioButton objects should almost always be
# children of a RadioGroup object (otherwise the RadioButton
# just degenerates into a checkbox, which might be what you
# want).
class RadioButton(RoundButton):
    # Constructor
    def __init__(self, parent=None):
        self.active = False
        self.zone = None
        RoundButton.__init__(self, parent)

    # RadioButtons require extra book keeping before destruction
    def kill(self):
        # Clear self in case it's active, so that the radio group
        # it's part of doesn't retain it as an active child.
        self.clear()
        RoundButton.kill(self)

    # Returns whether self is active or not.
    def isActive(self):
        return self.active

    # Quick method mainly for internal use. Returns whether this
    # radio button has a parent.
    def hasParent(self):
        return (self.parent != None)

    # Setting the radius scales the text size accordingly.
    # If you don't want radius changes to affect text, give
    # boolean False as the optional second argument.
    def radius(self, R=None, scaleText=True):
        if scaleText and R != None: self.textSize(1.5*R)
        return RoundButton.radius(self, R)

    # Change the width of the click zone that extends to the
    # right of the radio button. By default there is none.
    # Given 0 as input, zoneWidth() will kill the current
    # click zone. Given no args, returns current width
    # (returns 0 if there is no click zone)
    def clickZone(self, W=None):
        # If no argument given, return current width
        if W == None:
            if self.zone == None: return 0
            else: return self.zone.width()

        if self.zone == None:
            if W == 0: return self
            self.zone = RectButton(self)
            self.zone.position(-self.radius(), -self.radius()) \
                          .size(W, 2*self.radius()) \
                          .onPush(self.pushAction) \
                          .onRelease(self.releaseAction) \
                          .onClick(self.clickAction) \
                          .hide()
        elif W == 0: self.zone.kill()
        else: self.zone.width(W)
        return self

    ### Special book keeping needed for the event methods
    ### since a click zone might exist and need to be updated.
    def onPush(self, pushAction):
        RoundButton.onPush(self, pushAction)
        if self.zone != None: self.zone.onPush(self.pushAction)
        return self

    def onRelease(self, releaseAction):
        RoundButton.onRelease(self, releaseAction)
        if self.zone != None: self.zone.onRelease(self.releaseAction)
        return self

    # RadioButton requires special onClick() method to ensure
    # that radio button is activated when the click occurs.
    # Note that the button is activated BEFORE the clickAction
    # is called (in case that matters to your clickAction)
    def onClick(self, clickAction):
        def action():
            self.activate()
            clickAction()
        RoundButton.onClick(self, action)
        if self.zone != None: self.zone.onClick(self.clickAction)
        return self

    # Activates the radio button
    # Note: This won't call the clickAction!
    def activate(self):
        # Clear all radio buttons
        if self.hasParent():
            self.parent.clear()
            self.parent.activeChild = self
        # Activate THIS radio button.
        self.active = True
        return self

    # Deactivates the radio button
    def clear(self):
        if self.active and self.hasParent():
            self.parent.activeChild = None
        self.active = False
        return self

    # Does what .clear() does. Included for convenience.
    def deactivate(self):
        self.clear()
        return self

    # Reverses the radio button's active status.
    # active -> cleared; cleared -> active
    def toggle(self):
        if self.active: self.deactivate()
        else: self.activate()
        return self
    '''
    # Set on which side of the radio button the text will
    # appear. Given no args, returns current side.
    def textAlign(self, align=None):
        if align == None: return self.align
        self.align = align
        return self
    '''

    # Display the object
    def display(self):
        if self.isPushed: fill(self.PushedFill)
        else: fill(self.NormalFill)

        stroke(self.stroke)
        strokeWeight(self.strokeWeight())
        x, y = self.screenPosition()
        ellipse(x, y, 2*self.R, 2*self.R)

        if self.active:
            strokeWeight(0)
            fill("#000000")
            ellipse(x, y, self.R, self.R)

        textAlign(LEFT, CENTER)
        textSize(self.textSize())
        fill(self.textColor())
        trans = 2*self.radius()
        text(self.txt, x+trans, y)
