# Essential GUI classes and functions are defined below.

global GUI_list
GUI_list = []

# Null function used for GUI actions
def doNothing():
    pass

'''
The essential properties of GUI objects are captured here.
In practice, you should never need to worry about the GUI class;
it's job is as a superclass to subclasses like
RectButton, Radio, Checkboxes, Window, etc.
However, you may use the generic GUI class as a parent to other
sub-GUI's to aid in grouping related GUI objects together.

GUI's come in hierarchies. Any GUI object can have "child" GUI's
whose properties are partially dependent on the parent.
For example: position of a child GUI is relative to the position of
the parent. Also, if a parent GUI is killed, so are all its children.
Children are added to a GUI object when the child object is constructed
For example, to add a button to a Window object named window1
type this:

button1 = RectButton(window1)

The assignment is optional. You could have just as well typed

RectButton(window1)

All GUI objects have associated "action" functions that can be called
upon certain events like clicking. For example, you may have a button
that prints "Hello World" to the screen when clicked. You would define
your sayHello() function and then call this method:

button1.onClick(sayHello)

Now whenever button1 is clicked the function sayHello() is called.
SYNTAX NOTE: To give a GUI an action function, you must type

GUI_object.onClick(function)

don't type

GUI_object.onClick(function())

i.e. don't pass in a function CALL to the .onClick() method, pass
the literal function into it!
To run a single line of code, defining a function in unnecessary.
You can use lambdas. Example: Change text of button.

button1.onClick(lambda: button1.text("You clicked me!"))

Also note that by default, child GUI's inherit the event actions
of their parents until you specify otherwise.'''
class GUI(object):
    # Constructor. Takes a parent as an input. The parent gets
    # this new object as a child.
    def __init__(self, parent=None):
        self.Name = ""
        self.x = 0
        self.y = 0
        self.type = "GUI"
        self.visible = True
        #self.style = "standard"
        self.isPushed = False
        self.parent = parent
        self.children = []
        GUI_list.append(self)
        if parent != None:
            parent.children.append(self)
            # Child inherits event actions from parent
            self.onPush(self.parent.pushAction)
            self.onRelease(self.parent.releaseAction)
            self.onClick(self.parent.clickAction)
            self.onHover(self.parent.hoverAction)
            self.onPass(self.parent.passAction)
        else:
            # Default event actions to do nothing.
            self.onPush(doNothing)
            self.onRelease(doNothing)
            self.onClick(doNothing)
            self.onHover(doNothing)
            self.onPass(doNothing)

    # Destructor
    def kill(self):
       # Remove all children of the object
       for child in self.children[:]:
           child.kill()
       # Remove self from parent's children list (if it has a parent)
       if self.parent != None:
           self.parent.children.remove(self)
       # Remove self from the GUI_list
       GUI_list.remove(self)
       del self

    # Change the name of the GUI object.
    # Given no args, returns current name.
    def name(self, Name=None):
        if Name == None: return self.Name
        self.Name = Name
        return self

    # Changes the order of the given GUI to be in the place i
    # Higher i values mean more on top
    def order(self, i):
        global GUI_list
        i = i % len(GUI_list)
        GUI_list.remove(self)
        GUI_list = GUI_list[:i] + [self] + GUI_list[i:]

    # Moves the GUI object to the top of the GUI stack
    def onTop(self):
        self.order(-1)
        return self

    # Moves the GUI object to the bottom of the GUI stack
    def onBottom(self):
        self.order(0)
        return self

    # Makes the GUI object and all children visible (if they are displayable)
    # Passing False as optional arg hides ONLY the object (and not children)
    def show(self, includeChildren=True):
        self.visible = True
        if includeChildren:
            for child in self.children:
                child.show()
        return self

    # Makes the GUI object and all children invisible
    # Passing False as optional arg hides ONLY the object (and not children)
    def hide(self, includeChildren=True):
        self.visible = False
        if includeChildren:
            for child in self.children:
                child.hide()
        return self

    # Returns whether the GUI object is considered visible
    def isVisible(self):
        return self.visible

    # Set position of the GUI object
    # Given no arguments, returns current position
    # Position is always relative to the parent's position
    # If the GUI object has no parent, position wrt screen origin.
    def position(self, x=None, y=None):
       if x==None:
           return self.x, self.y
       self.x = x
       self.y = y
       return self

    # Returns the coords of the object relative to the screen
    # as a tuple (x,y)
    def screenPosition(self):
        if self.parent == None:
            return self.x, self.y
        # Recursively find parent's screen position
        # and add it to self's position
        x,y = self.parent.screenPosition()
        return self.x + x, self.y + y
    '''
    # Change style
    def setStyle(self, style):
        self.style = style
        return self'''

    # Change function to call when object is pushed
    def onPush(self, func):
        self.pushAction = func
        return self

    # Change the function to call when object is released
    def onRelease(self, func):
        self.releaseAction = func
        return self

    # Does the same as onRelease(). Included for convenience.
    def onCancel(self, func):
        self.onRelease(func)
        return self

    # Change the function to call when object is clicked
    def onClick(self, func):
        self.clickAction = func
        return self

    # Change the function to call when mouse hovers over object
    def onHover(self, func):
        self.hoverAction = func
        return self

    # Change the function to call when mouse stops hovering
    def onPass(self, func):
        self.passAction = func
        return self

    def underMouse(self):
        return False

    # Basic GUI has no visual form.
    def display(self):
        pass

# Displays every visible GUI in the GUI_list
def displayGUI():
    for gui in GUI_list:
        if gui.isVisible(): gui.display()

# Checks if the mouse is over any GUI.
# If it is, returns the topmost such GUI.
def GUIcollision():
    for i in range(len(GUI_list)-1, -1, -1):
        if GUI_list[i].underMouse():
            return GUI_list[i]
