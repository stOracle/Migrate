# Window class defined

from button import *

'''
This is the Window class. It's basically a big
Rectangular Button.'''
class Window(RectButton):
    # Constructor
    def __init__(self, parent=None):
        RectButton.__init__(self, parent)
        self.type = "Window"
        self.Title = ""
        self.width(200)
        self.height(100)
        self.normalFill("#8dceff")
        self.pushedFill("#8dceff")

    def color(self, col=None):
        RectButton.pushedFill(self, col)
        RectButton.normalFill(self, col)
        self.updateFill()
        return self
