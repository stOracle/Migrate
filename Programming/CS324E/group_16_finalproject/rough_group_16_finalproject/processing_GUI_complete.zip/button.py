# This module contains the classes for buttons

from guiheart import *

'''
Button superclass is defined here.
You shouldn't use this class either! This class's job
is to be a superclass to specific buttons like
RectButton, RoundButton, etc.

Buttons have two main states: pushed and released.
You can change the fill of the button during each
state with the corresponding methods below.

Text on the button is specified using the
text() method.
Text size is set using the .textSize() method.'''
class Button(GUI):
    # Constructor
    def __init__(self, parent=None):
        GUI.__init__(self, parent)
        self.type = "Button"
        self.stroke = "#000000"
        self.weight = 1
        self.NormalFill = "#FFFFFF"
        self.PushedFill = "#888888"
        self.fill = self.NormalFill
        self.txt = ""
        self.txtSize = 12
        self.txtColor = "#000000"

    # Set text to be read on the button
    # Given no args, returns current text
    def text(self, txt=None):
        if txt==None:
            return self.txt
        self.txt = txt
        return self

    # Set text size
    # Given no args, returns current size
    def textSize(self, Size=None):
        if Size == None:
            return self.txtSize
        self.txtSize = Size
        return self

    # Change the color of the text on the button
    # Given no args, returns current color (as string)
    def textColor(self, col=None):
        if col == None:
            return self.txtColor
        self.txtColor = col
        return self

    # Change the stroke weight
    # Given no args, returns current weight
    def strokeWeight(self, w=None):
        if w == None:
            return self.weight
        self.weight = w
        return self

    # Change the stroke color.
    # col = string of the form "#HEXDEC"
    # Given no args, returns current color (as HEXDEC string)
    def strokeColor(col=None):
        if col == None:
            return self.stroke
        self.stroke = col
        return self

    # Change the ordinary fill of the button
    # Given no args, returns current normal fill (as string)
    def normalFill(self, col=None):
        if col == None:
            return self.NormalFill
        self.NormalFill = col
        self.updateFill()
        return self

    # Does the same thing as normalFill().
    # Included for convenience.
    def color(self, col=None):
        return self.normalFill(col)

    # Change the pushed fill of the button
    # Given no args, returns current pushed fill (as string)
    def pushedFill(self, col=None):
        if col == None:
            return self.PushedFill
        self.PushedFill = col
        self.updateFill()
        return self

    # Updates the current state of fill based on whether
    # the button is pushed or not. Mainly for internal use.
    def updateFill(self):
        if self.isPushed: self.fill = self.PushedFill
        else: self.fill = self.NormalFill
        return self

    ### Event methods need extra commands so that
    ### the fills change according to state.
    def onPush(self, pushAction):
        def action():
            self.isPushed = True
            self.fill = self.PushedFill
            pushAction()
        GUI.onPush(self, action)
        return self

    def onRelease(self, releaseAction):
        def action():
            self.isPushed = False
            self.fill = self.NormalFill
            releaseAction()
        GUI.onRelease(self, action)
        return self

    def onClick(self, clickAction):
        def action():
            self.isPushed = False
            self.fill = self.NormalFill
            clickAction()
        GUI.onClick(self, action)
        return self

    # This is a generic button, still nothing to display
    def display(self):
        pass

# This is the rectangular button class
class RectButton(Button):
    # Constructor
    def __init__(self, parent=None):
        Button.__init__(self, parent)
        self.type = "RectButton"
        self.W = 25
        self.H = 50

    # Change width of button
    # Given no args, returns current width
    def width(self, W=None):
        if W == None:
            return self.W
        self.W = W
        return self

    # Change height of button
    # Given no args, returns current height
    def height(self, H=None):
        if H == None:
            return self.H
        self.H = H
        return self

    # Does width() and height() together at the same time.
    # Input two arguments to set the width and height
    # Given no args, returns width and height as tuple (W,H)
    def size(self, W=None, H=None):
        if W == None:
            return self.W, self.H
        self.W = W
        self.H = H
        return self

    # Display the object
    def display(self):
        fill(self.fill)
        stroke(self.stroke)
        strokeWeight(self.strokeWeight())
        x, y = self.screenPosition()
        rect(x, y, self.width(), self.height())
        textAlign(CENTER, CENTER)
        textSize(self.textSize())
        fill(self.textColor())
        text(self.txt, x+self.width()/2, y+self.height()/2)

    # Detect whether the mouse is over the button or not
    # Note that this doesn't take into account GUI object order!
    def underMouse(self):
        x, y = self.screenPosition()
        return x <= mouseX <= x+self.width() and \
               y <= mouseY <= y+self.height()

# Round button class defined here
class RoundButton(Button):
    # Constructor
    def __init__(self, parent=None):
        Button.__init__(self, parent)
        self.type = "RoundButton"
        self.R = 20

    # Change radius of button
    # Given no args, returns current radius
    def radius(self, R=None):
        if R == None:
            return self.R
        self.R = R
        return self

    # Display the object
    def display(self):
        fill(self.fill)
        stroke(self.stroke)
        strokeWeight(self.strokeWeight())
        x, y = self.screenPosition()
        ellipse(x, y, 2*self.R, 2*self.R)
        textAlign(CENTER, CENTER)
        textSize(self.textSize())
        fill(self.textColor())
        text(self.txt, x, y)

    # Detect whether the mouse is over the button or not
    # Note that this doesn't take into account GUI object order!
    def underMouse(self):
        x, y = self.screenPosition()
        return dist(x,y, mouseX, mouseY) <= self.radius()
