To run the extract_words.py script, ensure that the Sherlock.txt file is in the same directory 
as extract_words.py, then run the script.

To run the novel visualization for unique words, navigate to the a3_novelvisualization
folder, ensure that it contains uniquewords.txt from the extract_words.py script, and 
run the a3_novelvisualization.pde file. Click the play button to run.

To run the word frequency visualization, navigate to the a3_wordfrequency
folder, ensure that it contains wordfrequency.txt from the extract_words.py script, 
and run the a3_wordfrequency.pyde file. Click the play button to run.