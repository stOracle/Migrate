/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.model.text;

import javax.ide.model.Transaction;

/**
 *  The <CODE>TextModel</CODE> class. Encapsulates the
 *  {@link javax.swing.text.Document} interface to support 
 *  reading from and writing into the model.
 */
public interface TextModel extends Transaction 
{
  /**
   * Gets the {@link javax.swing.text.Document}.
   *
   * @return The text document.
   */
  public javax.swing.text.Document getDocument();
}
