/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.extension;

/**
 * The context when visiting an xml end element.
 */
public interface ElementEndContext extends ElementContext
{
  /**
   * Get text content of the element.
   * 
   * @return text content of the element.
   */
  public String getText();
}
