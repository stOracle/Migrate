/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.property;

/**
 * This exception should be thrown by {@link PropertyPage#onExit} 
 * implementors when the user enters an invalid property value.
 */
public class InvalidPropertyException extends Exception
{
  /**
   * Constructor.
   *
   * @param msg a short message indicating the problem.
   */
  public InvalidPropertyException( String msg )
  {
    super( msg );
  }
}
