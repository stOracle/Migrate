/*
 * @(#)ArrayTypeD.java
 */

package javax.ide.model.java.declaration;

/**
 * Represents an array type.
 *
 * @author Andy Yu
 */
public interface ArrayTypeD
  extends TypeD
{
  // ----------------------------------------------------------------------

  /**
   * @return The component type of this array. For example, if this
   * type is "int[]", this will return the type for "int". If this is
   * not an array type, this returns null (to match the behavior of
   * java/lang/Class).
   */
  public TypeD getComponentType();
}
