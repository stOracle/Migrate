/*
 * @(#)GenericD.java
 */

package javax.ide.model.java.declaration;

import java.util.Collection;

/**
 * Common supertype for Declaration elements that may declare type
 * parameters.
 *
 * @author Andy Yu
 */
public interface GenericD
  extends MemberD
{
  /**
   * Gets the declared type parameters. <p/>
   *
   * @return The type variable declarations for the declared type parameters.
   * <p/>
   *
   * Collection of TypeVariableDs.
   */
  public Collection getTypeParameters();
}
