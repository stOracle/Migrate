/*
 * @(#)ExpressionStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression statement. JLS3 14.8. <p/>
 *
 * @author Andy Yu
 * */
public interface ExpressionStatementT
  extends SimpleStatementT
{
}
